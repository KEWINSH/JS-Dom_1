// Oppgave 1

function rectangleThingy() {

  var høyden = prompt("Write the height of the rectangle. CM");
  
  var lengden = prompt("Write the length of the rectangle. CM");


  var perimeter = (2 * høyden) + (2 * lengden);
  var area = høyden * lengden;
  var volume = høyden * lengden;

  document.getElementById("a").innerHTML =
      "Area of rectangle:" + area;

  document.getElementById("p").innerHTML =
      "Perimeter of rectangle:" + perimeter;
}

// Oppgave 2